const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/pedidos
router.get('/', async (req, res, next) => {
    try {
        const [rows] = await pool.query(`
            SELECT p.id, c.nombre AS cliente, t.nombre AS transportista, e.nombre AS estado, p.fecha
            FROM Pedidos p
            LEFT JOIN Clientes c ON p.cliente_id = c.id
            LEFT JOIN Transportistas t ON p.transportista_id = t.id
            LEFT JOIN EstadosEnvio e ON p.estado_envio_id = e.id
            ORDER BY p.id DESC
        `);
        res.json(rows);
    } catch (err) { next(err); }
});

// GET /api/pedidos/:id
router.get('/:id', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Pedidos WHERE id=?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ error: 'Pedido no encontrado' });
        res.json(rows[0]);
    } catch (err) { next(err); }
});

// POST /api/pedidos
router.post('/', async (req, res, next) => {
    try {
        const { cliente_id, transportista_id, estado_envio_id } = req.body;
        if (!cliente_id) return res.status(400).json({ error: 'Falta cliente_id' });
        const [result] = await pool.query(
            'INSERT INTO Pedidos (cliente_id, transportista_id, estado_envio_id) VALUES (?, ?, ?)',
            [cliente_id, transportista_id || null, estado_envio_id || 1]
        );
        res.status(201).json({ id: result.insertId, cliente_id, transportista_id, estado_envio_id });
    } catch (err) { next(err); }
});

// PUT /api/pedidos/:id
router.put('/:id', async (req, res, next) => {
    try {
        const { cliente_id, transportista_id, estado_envio_id } = req.body;
        const [result] = await pool.query(
            'UPDATE Pedidos SET cliente_id=?, transportista_id=?, estado_envio_id=? WHERE id=?',
            [cliente_id, transportista_id, estado_envio_id, req.params.id]
        );
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Pedido no encontrado' });
        res.json({ message: 'Pedido actualizado' });
    } catch (err) { next(err); }
});

// DELETE /api/pedidos/:id
router.delete('/:id', async (req, res, next) => {
    try {
        const [result] = await pool.query('DELETE FROM Pedidos WHERE id=?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Pedido no encontrado' });
        res.json({ message: 'Pedido eliminado' });
    } catch (err) { next(err); }
});

module.exports = router;
