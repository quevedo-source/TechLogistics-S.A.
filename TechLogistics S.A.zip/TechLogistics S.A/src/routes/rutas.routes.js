const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET todas las rutas con info de pedido
router.get('/', async (req, res, next) => {
    try {
        const [rows] = await pool.query(`
            SELECT r.*, CONCAT('Pedido #', p.id) AS pedido
            FROM rutas r
            JOIN pedidos p ON r.pedido_id = p.id
            ORDER BY r.fecha DESC
        `);
        res.json(rows);
    } catch(err){ next(err); }
});

// GET ruta por ID
router.get('/:id', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM rutas WHERE id=?', [req.params.id]);
        if(!rows.length) return res.status(404).json({error:'Ruta no encontrada'});
        res.json(rows[0]);
    } catch(err){ next(err); }
});

// POST crear ruta
router.post('/', async (req, res, next) => {
    try {
        const { pedido_id, ubicacion } = req.body;
        if(!pedido_id || !ubicacion) return res.status(400).json({error:'Faltan campos'});
        const [result] = await pool.query(
            'INSERT INTO rutas (pedido_id, ubicacion) VALUES (?,?)',
            [pedido_id, ubicacion]
        );
        res.status(201).json({ id: result.insertId, pedido_id, ubicacion });
    } catch(err){ next(err); }
});

// PUT actualizar ruta
router.put('/:id', async (req, res, next) => {
    try {
        const { pedido_id, ubicacion } = req.body;
        const [result] = await pool.query(
            'UPDATE rutas SET pedido_id=?, ubicacion=? WHERE id=?',
            [pedido_id, ubicacion, req.params.id]
        );
        if(result.affectedRows === 0) return res.status(404).json({error:'Ruta no encontrada'});
        res.json({message:'Ruta actualizada'});
    } catch(err){ next(err); }
});

// DELETE ruta
router.delete('/:id', async (req,res,next) => {
    try {
        const [result] = await pool.query('DELETE FROM rutas WHERE id=?', [req.params.id]);
        if(result.affectedRows===0) return res.status(404).json({error:'Ruta no encontrada'});
        res.json({message:'Ruta eliminada'});
    } catch(err){ next(err); }
});

module.exports = router;
