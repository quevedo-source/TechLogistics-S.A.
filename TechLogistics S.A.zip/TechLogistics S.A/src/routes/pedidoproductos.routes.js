const express = require('express');
const router = express.Router();
const pool = require('../db');

// POST /api/pedidoproductos — Agregar producto a un pedido
router.post('/', async (req, res, next) => {
    try {
        const { pedido_id, producto_id, cantidad } = req.body;
        if (!pedido_id || !producto_id || !cantidad) {
            return res.status(400).json({ error: 'Faltan datos obligatorios' });
        }

        // Inserta producto en PedidoProductos tomando precio actual del producto
        const [result] = await pool.query(
            `INSERT INTO PedidoProductos (pedido_id, producto_id, cantidad, precio_unitario)
            SELECT ?, id, ?, precio FROM Productos WHERE id = ?`,
            [pedido_id, cantidad, producto_id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        res.status(201).json({ message: 'Producto agregado al pedido', pedidoProductoId: result.insertId });
    } catch (err) {
        next(err);
    }
});

// GET /api/pedidoproductos/:pedido_id — Listar productos de un pedido
router.get('/:pedido_id', async (req, res, next) => {
    try {
        const [rows] = await pool.query(
            `SELECT pp.id, pp.pedido_id, pp.producto_id, pr.nombre AS producto, pp.cantidad, pp.precio_unitario
            FROM PedidoProductos pp
            JOIN Productos pr ON pp.producto_id = pr.id
            WHERE pp.pedido_id = ?`,
            [req.params.pedido_id]
        );
        res.json(rows);
    } catch (err) { next(err); }
});

// DELETE /api/pedidoproductos/:id — Eliminar producto de un pedido
router.delete('/:id', async (req, res, next) => {
    try {
        const [result] = await pool.query('DELETE FROM PedidoProductos WHERE id=?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Producto del pedido no encontrado' });
        res.json({ message: 'Producto eliminado del pedido' });
    } catch (err) { next(err); }
});

module.exports = router;
