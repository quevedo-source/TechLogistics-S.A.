const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/estadosenvio — Listar todos los estados
router.get('/', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM EstadosEnvio ORDER BY id ASC');
        res.json(rows);
    } catch (err) { next(err); }
});

// GET /api/estadosenvio/:id — Obtener estado por ID
router.get('/:id', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM EstadosEnvio WHERE id=?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ error: 'Estado no encontrado' });
        res.json(rows[0]);
    } catch (err) { next(err); }
});

// POST /api/estadosenvio — Crear estado
router.post('/', async (req, res, next) => {
    try {
        const { nombre } = req.body;
        if (!nombre) return res.status(400).json({ error: 'Falta nombre del estado' });

        const [result] = await pool.query('INSERT INTO EstadosEnvio (nombre) VALUES (?)', [nombre]);
        res.status(201).json({ id: result.insertId, nombre });
    } catch (err) { next(err); }
});

// PUT /api/estadosenvio/:id — Actualizar estado
router.put('/:id', async (req, res, next) => {
    try {
        const { nombre } = req.body;
        const [result] = await pool.query('UPDATE EstadosEnvio SET nombre=? WHERE id=?', [nombre, req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Estado no encontrado' });
        res.json({ message: 'Estado actualizado' });
    } catch (err) { next(err); }
});

// DELETE /api/estadosenvio/:id — Eliminar estado
router.delete('/:id', async (req, res, next) => {
    try {
        const [result] = await pool.query('DELETE FROM EstadosEnvio WHERE id=?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Estado no encontrado' });
        res.json({ message: 'Estado eliminado' });
    } catch (err) { next(err); }
});

module.exports = router;
