require('dotenv').config();
const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Importar routers
const clientesRouter = require('./routes/clientes.routes');
const productosRouter = require('./routes/productos.routes');
const transportistasRouter = require('./routes/transportistas.routes');
const pedidosRouter = require('./routes/pedidos.routes');
const rutasRouter = require('./routes/rutas.routes');
const pedidoproductosRouter = require('./routes/pedidoproductos.routes');
const estadosenvioRouter = require('./routes/estadosenvio.routes');

// Montar routers
app.use('/api/clientes', clientesRouter);
app.use('/api/productos', productosRouter);
app.use('/api/transportistas', transportistasRouter);
app.use('/api/pedidos', pedidosRouter);
app.use('/api/rutas', rutasRouter);
app.use('/api/pedidoproductos', pedidoproductosRouter);
app.use('/api/estadosenvio', estadosenvioRouter);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✅ Servidor corriendo en http://localhost:${PORT}`);
});
