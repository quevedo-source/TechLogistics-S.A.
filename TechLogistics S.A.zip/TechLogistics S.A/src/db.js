const mysql = require('mysql2/promise');        // 1) Importa mysql2 con promesas

const pool = mysql.createPool({                 // 2) Crea un pool (grupo) de conexiones reutilizables
    host: process.env.DB_HOST,                    // 3) Host de MySQL desde .env
    user: process.env.DB_USER,                    // 4) Usuario de MySQL desde .env
    password: process.env.DB_PASSWORD || null,    // 5) Usa null si DB_PASSWORD está vacío
    database: process.env.DB_NAME,                // 6) Nombre de la base de datos
    waitForConnections: true,                     // 7) Espera si el pool está lleno
    connectionLimit: Number(process.env.DB_CONN_LIMIT || 10), // 8) Tamaño del pool
    queueLimit: 0                                 // 9) Sin límite en la cola de espera
});                                             // 10) Fin de la configuración

module.exports = pool;                          // 11) Exporta el pool para usarlo en las rutas
