const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/clientes — lista todos
router.get('/', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM clientes ORDER BY id DESC');
        res.json(rows);
    } catch (err) { next(err); }
});

// GET /api/clientes/:id — uno por id
router.get('/:id', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM clientes WHERE id = ?', [req.params.id]);
        if(rows.length === 0) return res.status(404).json({error:'Cliente no encontrado'});
        res.json(rows[0]);
    } catch(err){ next(err); }
});

// POST /api/clientes — crea
router.post('/', async (req,res,next) => {
    try{
        const { nombre, email } = req.body;
        if(!nombre || !email) return res.status(400).json({error:'Faltan campos'});
        const [result] = await pool.query('INSERT INTO clientes (nombre, email) VALUES (?,?)', [nombre, email]);
        res.status(201).json({ id: result.insertId, nombre, email });
    } catch(err){ next(err); }
});

// PUT /api/clientes/:id — actualiza
router.put('/:id', async (req,res,next) => {
    try{
        const { nombre, email } = req.body;
        const [result] = await pool.query('UPDATE clientes SET nombre=?, email=? WHERE id=?', [nombre, email, req.params.id]);
        if(result.affectedRows === 0) return res.status(404).json({error:'Cliente no encontrado'});
        res.json({message:'Cliente actualizado'});
    } catch(err){ next(err); }
});

// DELETE /api/clientes/:id
router.delete('/:id', async (req,res,next) => {
    try{
        const [result] = await pool.query('DELETE FROM clientes WHERE id=?', [req.params.id]);
        if(result.affectedRows === 0) return res.status(404).json({error:'Cliente no encontrado'});
        res.json({message:'Cliente eliminado'});
    } catch(err){ next(err); }
});

module.exports = router;
