const express = require('express');
const router = express.Router();
const pool = require('../db');

// GET /api/transportistas
router.get('/', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Transportistas ORDER BY id DESC');
        res.json(rows);
    } catch (err) { next(err); }
});

// GET /api/transportistas/:id
router.get('/:id', async (req, res, next) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Transportistas WHERE id = ?', [req.params.id]);
        if (!rows.length) return res.status(404).json({ error: 'Transportista no encontrado' });
        res.json(rows[0]);
    } catch (err) { next(err); }
});

// POST /api/transportistas
router.post('/', async (req, res, next) => {
    try {
        const { nombre, telefono, email } = req.body;
        if (!nombre) return res.status(400).json({ error: 'Falta nombre' });
        const [result] = await pool.query(
            'INSERT INTO Transportistas (nombre, telefono, email) VALUES (?, ?, ?)',
            [nombre, telefono, email]
        );
        res.status(201).json({ id: result.insertId, nombre, telefono, email });
    } catch (err) { next(err); }
});

// PUT /api/transportistas/:id
router.put('/:id', async (req, res, next) => {
    try {
        const { nombre, telefono, email } = req.body;
        const [result] = await pool.query(
            'UPDATE Transportistas SET nombre=?, telefono=?, email=? WHERE id=?',
            [nombre, telefono, email, req.params.id]
        );
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Transportista no encontrado' });
        res.json({ message: 'Transportista actualizado' });
    } catch (err) { next(err); }
});

// DELETE /api/transportistas/:id
router.delete('/:id', async (req, res, next) => {
    try {
        const [result] = await pool.query('DELETE FROM Transportistas WHERE id=?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ error: 'Transportista no encontrado' });
        res.json({ message: 'Transportista eliminado' });
    } catch (err) { next(err); }
});

module.exports = router;
