// app.js - Funciones y utilidades comunes para TechLogistics

// Selector rápido
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

// Función para cargar datos en un select desde API
async function cargarSelect(url, selectId, campoNombre = 'nombre', placeholder = '--Seleccione--') {
    try {
        const res = await fetch(url);
        const data = await res.json();
        const select = $(selectId);
        select.innerHTML = `<option value="">${placeholder}</option>`;
        data.forEach(item => {
            const option = document.createElement('option');
            option.value = item.id;
            option.textContent = item[campoNombre];
            select.appendChild(option);
        });
    } catch (err) {
        console.error(`Error cargando select ${selectId} desde ${url}:`, err);
        const select = $(selectId);
        if(select) select.innerHTML = `<option value="">Error al cargar</option>`;
    }
}

// Función genérica para GET de API
async function fetchGET(url) {
    try {
        const res = await fetch(url);
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('Error en fetchGET:', err);
        return null;
    }
}

// Función genérica para POST o PUT de API
async function fetchSend(url, data, method = 'POST') {
    try {
        const res = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error(`Error en fetchSend (${method} ${url}):`, err);
        return null;
    }
}

// Función genérica para DELETE de API
async function fetchDELETE(url) {
    try {
        const res = await fetch(url, { method: 'DELETE' });
        if(!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error(`Error en fetchDELETE (${url}):`, err);
        return null;
    }
}

// Función para resetear formulario y botones
function resetForm(formId, inputId, cancelarId, guardarId, textoGuardar='Guardar') {
    const form = $(formId);
    if(form) form.reset();
    const input = $(inputId);
    if(input) input.value = '';
    const cancelar = $(cancelarId);
    if(cancelar) cancelar.classList.add('hidden');
    const guardar = $(guardarId);
    if(guardar) guardar.textContent = textoGuardar;
}

// Función para mostrar mensaje simple en consola y alerta
function mostrarMensaje(msg, tipo='info') {
    console.log(`[${tipo.toUpperCase()}] ${msg}`);
    alert(msg);
}
